# Tugas UAS SPK

Nama : Nabilla <br>
NIM : 201011400588 <br>
Kelas : 07-TPLP-012 <br>

## Install requirements

`pip install -r requirements.txt`

## Run the app

Untuk menjalankan:
`python main.py`
